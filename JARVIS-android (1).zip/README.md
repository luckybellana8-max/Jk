# JARVIS (Android)
Kotlin + Jetpack Compose. Build locally with Android Studio or in the cloud with GitHub Actions
(.github/workflows/build.yml). Keep this repository PRIVATE: API keys are compiled into the APK.
