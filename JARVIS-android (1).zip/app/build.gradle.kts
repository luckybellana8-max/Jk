import java.util.Properties

val localProps = Properties().apply {
    rootProject.file("local.properties").takeIf { it.exists() }
        ?.inputStream()?.use { load(it) }
}
fun key(name: String) = "\"${localProps.getProperty(name, "")}\""

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
    alias(libs.plugins.hilt)
}

// Firebase plugin only when google-services.json is present, so the first build never fails.
if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

android {
    namespace = "com.jarvis.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jarvis.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.6.1"

        buildConfigField("String", "OPENROUTER_API_KEY", key("OPENROUTER_API_KEY"))
        buildConfigField("String", "GOOGLE_AI_STUDIO_API_KEY", key("GOOGLE_AI_STUDIO_API_KEY"))
        buildConfigField("String", "GROQ_API_KEY", key("GROQ_API_KEY"))
        buildConfigField("String", "OPENWEATHER_API_KEY", key("OPENWEATHER_API_KEY"))
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", key("GOOGLE_WEB_CLIENT_ID"))
        buildConfigField("String", "YOUTUBE_API_KEY", key("YOUTUBE_API_KEY"))
        buildConfigField("String", "RAZORPAY_KEY_ID", key("RAZORPAY_KEY_ID"))
        buildConfigField("String", "ELEVENLABS_API_KEY", key("ELEVENLABS_API_KEY"))
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildFeatures { compose = true; buildConfig = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform(libs.compose.bom))
    implementation(libs.compose.ui)
    implementation(libs.compose.material3)
    implementation(libs.activity.compose)
    implementation(libs.lifecycle.vm)
    implementation(libs.lifecycle.runtime)
    implementation(libs.navigation)
    debugImplementation(libs.compose.tooling)

    implementation(libs.hilt.android)
    ksp(libs.hilt.compiler)
    implementation(libs.hilt.nav)

    implementation(libs.coroutines)
    implementation(libs.coroutines.play)

    implementation(platform(libs.firebase.bom))
    implementation(libs.firebase.auth)
    implementation(libs.credentials)
    implementation(libs.credentials.play)
    implementation(libs.google.id)
    implementation(libs.play.location)

    implementation(libs.media3.transformer)
    implementation(libs.media3.effect)
    implementation(libs.media3.exoplayer)
    implementation(libs.media3.ui)
    implementation(libs.media3.common)
    implementation(libs.guava)
}
