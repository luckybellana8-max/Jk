package com.jarvis.app.auth

import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.jarvis.app.BuildConfig
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import javax.inject.Inject

sealed interface AuthState {
    data object SignedOut : AuthState
    data object Loading : AuthState
    data object SignedIn : AuthState
    data class Error(val message: String) : AuthState
}

@HiltViewModel
class AuthViewModel @Inject constructor() : ViewModel() {
    private val auth: FirebaseAuth? = runCatching { FirebaseAuth.getInstance() }.getOrNull()

    private val _state = MutableStateFlow<AuthState>(
        if (auth?.currentUser != null) AuthState.SignedIn else AuthState.SignedOut
    )
    val state: StateFlow<AuthState> = _state.asStateFlow()

    /** [activityContext] must be an Activity context (use LocalContext in Compose). */
    fun signInWithGoogle(activityContext: Context) {
        viewModelScope.launch {
            if (auth == null) {
                _state.value = AuthState.Error("Firebase is not set up yet (google-services.json missing)")
                return@launch
            }
            _state.value = AuthState.Loading
            try {
                val option = GetSignInWithGoogleOption.Builder(BuildConfig.GOOGLE_WEB_CLIENT_ID).build()
                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                val credential = CredentialManager.create(activityContext)
                    .getCredential(activityContext, request).credential

                if (credential is CustomCredential &&
                    credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
                ) {
                    val idToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    auth.signInWithCredential(GoogleAuthProvider.getCredential(idToken, null)).await()
                    _state.value = AuthState.SignedIn
                } else {
                    _state.value = AuthState.Error("Unsupported sign-in credential")
                }
            } catch (e: GetCredentialException) {
                _state.value = AuthState.Error(e.message ?: "Sign-in cancelled")
            } catch (e: Exception) {
                _state.value = AuthState.Error(e.message ?: "Sign-in failed")
            }
        }
    }

    fun signOut() {
        auth?.signOut()
        _state.value = AuthState.SignedOut
    }
}
