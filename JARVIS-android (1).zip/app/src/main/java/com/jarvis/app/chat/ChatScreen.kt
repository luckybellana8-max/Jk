package com.jarvis.app.chat

import android.Manifest
import android.app.Activity
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jarvis.app.ui.theme.*

@Composable
fun ChatScreen(onBack: () -> Unit, vm: ChatViewModel = hiltViewModel()) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.attach(context, uri)
    }
    val perms = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }
    LaunchedEffect(Unit) {
        val needed = listOf(
            Manifest.permission.READ_CONTACTS, Manifest.permission.SEND_SMS, Manifest.permission.CALL_PHONE
        ).filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }
        if (needed.isNotEmpty()) perms.launch(needed.toTypedArray())
    }
    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) {
            val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!said.isNullOrBlank()) vm.send(context, said)
        }
    }
    LaunchedEffect(vm.messages.size) {
        if (vm.messages.isNotEmpty()) listState.animateScrollToItem(vm.messages.size - 1)
    }

    Column(Modifier.fillMaxSize().background(HudBlack).systemBarsPadding().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< HUD", color = HudCyan) }
            Spacer(Modifier.weight(1f))
            Box {
                TextButton(onClick = { menu = true }) {
                    Text("MODEL: " + vm.models.first { it.second == vm.model }.first, color = HudGold, fontSize = 12.sp)
                }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    vm.models.forEach { (label, id) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { vm.model = id; menu = false })
                    }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.messages.isEmpty()) {
                Text("Ask me anything, Sir.", color = HudDimCyan, modifier = Modifier.align(Alignment.Center))
            }
            LazyColumn(
                state = listState,
                modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) { items(vm.messages) { Bubble(it) } }
        }

        if (vm.loading) Text("JARVIS is thinking...", color = HudGold, fontSize = 12.sp, modifier = Modifier.padding(start = 16.dp))
        vm.notice?.let {
            Text(it, color = HudGold, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).clickable { vm.dismissNotice() })
        }
        vm.attachName?.let {
            Text("[file] $it   (tap to remove)", color = HudCyan, fontSize = 12.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp).clickable { vm.clearAttachment() })
        }

        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedButton(
                onClick = { picker.launch("*/*") },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(48.dp)
            ) { Text("+", color = HudCyan, fontSize = 22.sp) }
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = {
                    try {
                        voice.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to JARVIS")
                        })
                    } catch (e: Exception) {
                        vm.showNotice("Voice input needs the Google app / speech services on this phone, Sir.")
                    }
                },
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(0.dp),
                modifier = Modifier.size(48.dp)
            ) { Text("MIC", color = HudGold, fontSize = 11.sp) }
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ask JARVIS...", color = HudDimCyan) },
                maxLines = 4,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = HudCyan, unfocusedTextColor = HudCyan,
                    focusedBorderColor = HudCyan, unfocusedBorderColor = HudDimCyan,
                    cursorColor = HudCyan
                )
            )
            Spacer(Modifier.width(8.dp))
            Button(
                onClick = { vm.send(context, input); input = "" },
                colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = HudBlack),
                shape = RoundedCornerShape(8.dp)
            ) { Text("SEND") }
        }
    }
}

@Composable
private fun Bubble(m: UiMsg) {
    val mine = m.role == "user"
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start) {
        Box(
            Modifier.widthIn(max = 300.dp)
                .border(1.dp, if (mine) HudGold else HudCyan, RoundedCornerShape(8.dp))
                .padding(10.dp)
        ) { Text(m.shown, color = if (mine) HudGold else HudCyan, fontSize = 14.sp) }
    }
}
