package com.jarvis.app.chat

import android.content.ContentResolver
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.app.commands.AppCommands
import com.jarvis.app.core.Persona
import com.jarvis.app.data.OpenRouterClient
import com.jarvis.app.voice.TtsManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import javax.inject.Inject

class UiMsg(val role: String, val shown: String, val apiText: String, val image: String? = null)

@HiltViewModel
class ChatViewModel @Inject constructor(private val tts: TtsManager) : ViewModel() {

    // Model IDs come from openrouter.ai/models. Edit this list any time.
    val models = listOf(
        "GPT-4o mini" to "openai/gpt-4o-mini",
        "Gemini Flash" to "google/gemini-2.0-flash-001",
        "DeepSeek" to "deepseek/deepseek-chat",
        "Llama 3.3 70B" to "meta-llama/llama-3.3-70b-instruct",
        "Claude Haiku" to "anthropic/claude-3.5-haiku"
    )

    val messages = mutableStateListOf<UiMsg>()
    var loading by mutableStateOf(false); private set
    var model by mutableStateOf(models[0].second)
    var attachName by mutableStateOf<String?>(null); private set
    var notice by mutableStateOf<String?>(null); private set
    private var attachText: String? = null
    private var attachImage: String? = null

    fun dismissNotice() { notice = null }

    fun clearAttachment() { attachName = null; attachText = null; attachImage = null }

    fun showNotice(msg: String) { notice = msg }

    fun send(context: Context, input: String) {
        if (loading || (input.isBlank() && attachName == null)) return
        if (attachName == null) {
            val local = AppCommands.handle(context, input)
            if (local != null) {
                messages.add(UiMsg("user", input, input))
                val reply = Persona.enforce(local)
                messages.add(UiMsg("assistant", reply, reply))
                tts.speak(reply)
                return
            }
        }
        val prompt = input.ifBlank { "Please look at the attached file and summarize it." }
        val name = attachName
        val apiText = if (attachText != null) "$prompt\n\n[Attached file: $name]\n$attachText" else prompt
        val shown = if (name != null) "[file] $name\n$prompt" else prompt
        messages.add(UiMsg("user", shown, apiText, attachImage))
        clearAttachment()
        loading = true
        viewModelScope.launch {
            val lastUser = messages.indexOfLast { it.role == "user" }
            val history = messages.mapIndexed { i, m ->
                OpenRouterClient.Msg(m.role, m.apiText, if (i == lastUser) m.image else null)
            }
            val reply = Persona.enforce(OpenRouterClient.chat(history, model))
            messages.add(UiMsg("assistant", reply, reply))
            loading = false
            tts.speak(reply)
        }
    }

    fun attach(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val cr = context.contentResolver
                val mime = cr.getType(uri) ?: ""
                var name = "file"
                cr.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i)
                }
                val ext = name.substringAfterLast('.', "").lowercase()
                val textExt = setOf("txt", "md", "csv", "json", "kt", "py", "js", "html", "xml", "java", "log")
                when {
                    mime.startsWith("image/") -> {
                        val data = withContext(Dispatchers.IO) { imageToDataUri(cr, uri) }
                        attachName = name; attachImage = data; attachText = null
                    }
                    mime.startsWith("text/") || ext in textExt -> {
                        val t = withContext(Dispatchers.IO) {
                            cr.openInputStream(uri)!!.bufferedReader().use { it.readText() }.take(30000)
                        }
                        attachName = name; attachText = t; attachImage = null
                    }
                    else -> notice = "That file type (PDF, audio, video) is not supported yet. Images and text files work, Sir."
                }
            } catch (e: Exception) {
                notice = "I could not open that file: ${e.message}"
            }
        }
    }

    private fun imageToDataUri(cr: ContentResolver, uri: Uri): String {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        val bmp = cr.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: error("Cannot read image")
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, out)
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }
}
