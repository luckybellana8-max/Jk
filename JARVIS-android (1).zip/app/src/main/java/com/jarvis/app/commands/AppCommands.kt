package com.jarvis.app.commands

import android.content.Context
import android.content.Intent
import android.Manifest
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.telephony.SmsManager
import android.provider.ContactsContract
import android.webkit.URLUtil
import androidx.core.content.ContextCompat

/** Handles typed or spoken phone commands before anything goes to the AI. */
object AppCommands {
    private val apps = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "gmail" to "com.google.android.gm",
        "instagram" to "com.instagram.android",
        "telegram" to "org.telegram.messenger",
        "maps" to "com.google.android.apps.maps",
        "facebook" to "com.facebook.katana",
        "spotify" to "com.spotify.music",
        "drive" to "com.google.android.apps.docs",
        "photos" to "com.google.android.apps.photos"
    )

    // Used only when the app is not installed.
    private val websites = mapOf(
        "youtube" to "https://www.youtube.com",
        "google" to "https://www.google.com",
        "gmail" to "https://mail.google.com",
        "instagram" to "https://www.instagram.com",
        "facebook" to "https://www.facebook.com",
        "whatsapp" to "https://web.whatsapp.com",
        "maps" to "https://maps.google.com"
    )

    private val momWords = listOf("mom", "mother", "mummy", "amma", "mamma")
    private val dadWords = listOf("dad", "father", "papa", "nanna", "daddy")
    private val notNames = setOf("me", "us", "him", "her", "them", "a", "the", "jarvis", "everyone")

    /** Returns JARVIS's reply if this was a phone command, or null to let the AI answer. */
    fun handle(context: Context, text: String): String? {
        val t = text.lowercase().trim().trimEnd('.', '!', '?')
            .replace(Regex("\\b(please|jarvis|for me|now)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()

        // "Tell Mom I will be late" -> JARVIS sends a Telugu SMS by itself.
        val late = Regex("(?:^|\\s)(?:tell|inform|text|message|sms)\\s+(?:my\\s+)?([a-z]+)\\b.*\\blate\\b").find(t)
        if (late != null && who0(late) !in notNames && Regex("\\bi\\b|\\bi'm\\b|\\bi'll\\b|\\bim\\b").containsMatchIn(t)) {
            val who = who0(late)
            val granted = listOf(Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS).all {
                ContextCompat.checkSelfPermission(context, it) == PackageManager.PERMISSION_GRANTED
            }
            if (!granted) return "I need the contacts and SMS permissions. Allow them in the app settings"
            val found = findContactAny(context, who) ?: return "I could not find $who in your contacts"
            val greeting = when (who) {
                in momWords -> "అమ్మా"
                in dadWords -> "నాన్నా"
                else -> "నమస్కారం"
            }
            val msg = "$greeting, నేను కొంచెం ఆలస్యంగా వస్తాను. కంగారు పడకండి. (JARVIS ద్వారా పంపబడింది)"
            return try {
                sendSms(context, found.second, msg)
                "Informed ${found.first} in Telugu"
            } catch (e: Exception) {
                "I could not send the message: ${e.message}"
            }
        }

        // Browser commands: search, go to a website, download a direct link.
        Regex("(?:^|\\s)(?:search|find|look up|play)\\s+(?:on\\s+)?youtube\\s+(?:for\\s+)?(.+)$").find(t)?.let {
            return openUrl(context, "https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1]),
                "Searching YouTube for ${it.groupValues[1]}")
        }
        Regex("(?:^|\\s)(?:search|find|look up|play)\\s+(.+?)\\s+on\\s+youtube$").find(t)?.let {
            return openUrl(context, "https://www.youtube.com/results?search_query=" + Uri.encode(it.groupValues[1]),
                "Searching YouTube for ${it.groupValues[1]}")
        }
        Regex("^(?:search|google|look up)\\s+(?:for\\s+)?(.+)$").find(t)?.let {
            return openUrl(context, "https://www.google.com/search?q=" + Uri.encode(it.groupValues[1]),
                "Searching Google for ${it.groupValues[1]}")
        }
        Regex("^(?:go to|goto|visit|open website|open site)\\s+(\\S+)$").find(t)?.let {
            val site = it.groupValues[1]
            val host = if (site.contains(".")) site else "$site.com"
            return openUrl(context, if (host.startsWith("http")) host else "https://$host", "Opening $site")
        }
        Regex("(?:^|\\s)download\\s+(https?://\\S+)", RegexOption.IGNORE_CASE).find(text)?.let {
            val url = it.groupValues[1]
            val name = URLUtil.guessFileName(url, null, null)
            if (name.lowercase().endsWith(".apk")) return "I will not download app installers automatically"
            return try {
                val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                dm.enqueue(
                    DownloadManager.Request(Uri.parse(url))
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                )
                "Downloading $name to your Downloads folder"
            } catch (e: Exception) {
                "I could not start that download: ${e.message}"
            }
        }

        val open = Regex("(?:^|\\s)(?:open|launch|start|run)\\s+(?:the\\s+)?(.+?)(?:\\s+app)?$").find(t)
        if (open != null) {
            val name = open.groupValues[1].trim()
            if (name.isNotEmpty() && name.split(" ").size <= 3) {
                findLaunchIntent(context, name)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(it)
                    return "Opening $name"
                }
                websites.entries.firstOrNull { name.contains(it.key) }?.let {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse(it.value)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                    return "Opening $name in the browser"
                }
                if (t.startsWith("open") || t.startsWith("launch")) return "I could not find an app called $name"
            }
        }

        val call = Regex("(?:^|\\s)(?:call|dial)\\s+([+0-9 ]{5,})$").find(t)
        if (call != null) {
            val number = call.groupValues[1].replace(" ", "")
            return if (placeCall(context, number)) "Calling $number"
            else "Opening the dialer for $number. Allow the Phone permission for direct calls"
        }

        val callName = Regex("(?:^|\\s)(?:call|dial|phone)\\s+(?:my\\s+)?([a-z][a-z ]{1,28})$").find(t)
        if (callName != null) {
            val who = callName.groupValues[1].trim()
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CONTACTS) !=
                PackageManager.PERMISSION_GRANTED
            ) return "I need the contacts permission to find $who. Allow it in the app settings"
            val found = findContactAny(context, who) ?: return "I could not find $who in your contacts"
            return if (placeCall(context, found.second)) "Calling ${found.first}"
            else "Opening the dialer for ${found.first}. Allow the Phone permission for direct calls"
        }
        return null
    }

    private fun openUrl(context: Context, url: String, reply: String): String {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return reply
    }

    /** Places the call directly when the Phone permission is allowed, otherwise opens the dialer. */
    private fun placeCall(context: Context, rawNumber: String): Boolean {
        val number = rawNumber.filter { it.isDigit() || it == '+' }
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) ==
            PackageManager.PERMISSION_GRANTED
        val action = if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL
        context.startActivity(Intent(action, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return granted
    }

    private fun who0(m: MatchResult) = m.groupValues[1]

    private fun sendSms(context: Context, number: String, message: String) {
        val sms = if (Build.VERSION.SDK_INT >= 31) context.getSystemService(SmsManager::class.java)
        else @Suppress("DEPRECATION") SmsManager.getDefault()
        sms.sendMultipartTextMessage(number, null, sms.divideMessage(message), null, null)
    }

    private fun findContactAny(context: Context, who: String): Pair<String, String>? {
        val names = when (who) {
            in momWords -> momWords
            in dadWords -> dadWords
            else -> listOf(who)
        }
        for (n in names) findContact(context, n)?.let { return it }
        return null
    }

    private fun findContact(context: Context, name: String): Pair<String, String>? {
        val cursor = context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%$name%"),
            null
        ) ?: return null
        cursor.use {
            if (it.moveToFirst()) return Pair(it.getString(0), it.getString(1))
        }
        return null
    }

    private fun findLaunchIntent(context: Context, name: String): Intent? {
        val pm = context.packageManager
        apps.entries.firstOrNull { name.contains(it.key) }?.let { e ->
            pm.getLaunchIntentForPackage(e.value)?.let { return it }
        }
        // Any installed app, matched by its name on the home screen.
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0)
            .firstOrNull { it.loadLabel(pm).toString().lowercase().contains(name) }
        return match?.let { pm.getLaunchIntentForPackage(it.activityInfo.packageName) }
    }
}
