package com.jarvis.app.core

/** The JARVIS persona: every spoken or written reply must end with "Sir." */
object Persona {
    const val GREETING = "Good morning, Sir."

    const val SYSTEM_PROMPT =
        "You are J.A.R.V.I.S, a calm, witty, highly capable AI butler. " +
        "Be concise and precise. Always address the user as Sir. " +
        "Every reply MUST end with the word \"Sir.\""

    /** Guarantees the final word is "Sir." no matter what the AI returned. */
    fun enforce(text: String): String {
        val t = text.trim().trimEnd('.', '!', '?', ',', ' ')
        if (t.isEmpty()) return "Sir."
        return if (t.endsWith("Sir", ignoreCase = true)) "$t." else "$t, Sir."
    }
}
