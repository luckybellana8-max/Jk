package com.jarvis.app.data

import com.jarvis.app.BuildConfig
import com.jarvis.app.core.Persona
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Sends chat requests to OpenRouter using the key from local.properties. */
object OpenRouterClient {
    class Msg(val role: String, val text: String, val imageDataUri: String? = null)

    suspend fun chat(history: List<Msg>, model: String): String = withContext(Dispatchers.IO) {
        val key = BuildConfig.OPENROUTER_API_KEY
        if (key.isBlank()) return@withContext "My OpenRouter key is missing. Add OPENROUTER_API_KEY as a GitHub secret and rebuild"
        try {
            val messages = JSONArray()
            messages.put(JSONObject().put("role", "system").put("content", Persona.SYSTEM_PROMPT))
            for (m in history) {
                val content: Any = if (m.imageDataUri != null) {
                    JSONArray()
                        .put(JSONObject().put("type", "text").put("text", m.text))
                        .put(JSONObject().put("type", "image_url")
                            .put("image_url", JSONObject().put("url", m.imageDataUri)))
                } else m.text
                messages.put(JSONObject().put("role", m.role).put("content", content))
            }
            val body = JSONObject().put("model", model).put("messages", messages).toString()

            val conn = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 90000
                doOutput = true
                setRequestProperty("Authorization", "Bearer $key")
                setRequestProperty("Content-Type", "application/json")
                setRequestProperty("X-Title", "JARVIS")
            }
            conn.outputStream.use { it.write(body.toByteArray()) }
            val code = conn.responseCode
            val text = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) {
                val msg = runCatching { JSONObject(text).getJSONObject("error").getString("message") }
                    .getOrDefault(text.take(200))
                return@withContext "OpenRouter error $code: $msg"
            }
            JSONObject(text).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
        } catch (e: Exception) {
            "I could not reach OpenRouter: ${e.message}"
        }
    }
}
