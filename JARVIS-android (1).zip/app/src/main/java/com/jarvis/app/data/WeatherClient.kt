package com.jarvis.app.data

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.jarvis.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Live weather for the phone's current location, from OpenWeatherMap. */
object WeatherClient {
    @SuppressLint("MissingPermission")
    suspend fun forCurrentLocation(context: Context): String {
        val key = BuildConfig.OPENWEATHER_API_KEY
        if (key.isBlank()) return "Add the OPENWEATHER_API_KEY secret in GitHub and rebuild"
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return "Location permission is off"
        return try {
            val client = LocationServices.getFusedLocationProviderClient(context)
            val loc = client.getCurrentLocation(
                Priority.PRIORITY_BALANCED_POWER_ACCURACY, CancellationTokenSource().token
            ).await() ?: client.lastLocation.await()
                ?: return "Could not get your location. Turn on GPS and try again"
            withContext(Dispatchers.IO) {
                val url = URL(
                    "https://api.openweathermap.org/data/2.5/weather?lat=${loc.latitude}" +
                        "&lon=${loc.longitude}&units=metric&appid=$key"
                )
                val conn = url.openConnection() as HttpURLConnection
                conn.connectTimeout = 15000
                conn.readTimeout = 15000
                val code = conn.responseCode
                val body = (if (code in 200..299) conn.inputStream else conn.errorStream)
                    ?.bufferedReader()?.use { it.readText() } ?: ""
                if (code != 200) {
                    return@withContext "Weather error $code" +
                        if (code == 401) " (key wrong or not active yet, new keys take a few hours)" else ""
                }
                val j = JSONObject(body)
                val temp = j.getJSONObject("main").getDouble("temp").roundToInt()
                val desc = j.getJSONArray("weather").getJSONObject(0).getString("description")
                    .replaceFirstChar { it.uppercase() }
                "$temp\u00B0C  $desc\n${j.optString("name")}"
            }
        } catch (e: Exception) {
            "Weather unavailable: ${e.message}"
        }
    }
}
