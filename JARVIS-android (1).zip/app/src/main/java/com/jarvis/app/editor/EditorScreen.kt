package com.jarvis.app.editor

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.jarvis.app.ui.theme.*
import kotlinx.coroutines.delay

private fun fmt(ms: Float): String {
    val s = (ms / 1000f).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditorScreen(onBack: () -> Unit, vm: EditorViewModel = hiltViewModel()) {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) vm.setVideo(context, uri)
    }

    LaunchedEffect(vm.videoUri) {
        vm.videoUri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
        }
    }
    // Keep preview playback inside the trimmed range.
    LaunchedEffect(Unit) {
        while (true) {
            if (player.isPlaying && player.currentPosition >= vm.trimEndMs) {
                player.pause()
                player.seekTo(vm.trimStartMs.toLong())
            }
            delay(150)
        }
    }

    Column(
        Modifier.fillMaxSize().background(HudBlack).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text("< HUD", color = HudCyan) }
            Spacer(Modifier.weight(1f))
            Text("VIDEO EDITOR", color = HudGold, fontSize = 14.sp, letterSpacing = 3.sp)
        }

        if (vm.videoUri == null) {
            Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) {
                Text("No video yet", color = HudDimCyan)
            }
        } else {
            AndroidView(
                factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
                modifier = Modifier.fillMaxWidth().height(260.dp)
            )
        }

        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { picker.launch("video/*") },
            colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = HudBlack),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth()
        ) { Text(if (vm.videoUri == null) "PICK VIDEO" else "CHANGE VIDEO") }

        if (vm.videoUri != null) {
            Spacer(Modifier.height(16.dp))
            Text("TRIM   ${fmt(vm.trimStartMs)}  -  ${fmt(vm.trimEndMs)}", color = HudGold, fontSize = 12.sp)
            RangeSlider(
                value = vm.trimStartMs..vm.trimEndMs,
                onValueChange = { r ->
                    vm.trimStartMs = r.start
                    vm.trimEndMs = r.endInclusive
                },
                onValueChangeFinished = { player.seekTo(vm.trimStartMs.toLong()) },
                valueRange = 0f..vm.durationMs.toFloat(),
                colors = SliderDefaults.colors(
                    thumbColor = HudCyan, activeTrackColor = HudCyan, inactiveTrackColor = HudDimCyan
                )
            )

            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = vm.overlayText,
                onValueChange = { vm.overlayText = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Text on video (optional)", color = HudDimCyan) },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = HudCyan, unfocusedTextColor = HudCyan,
                    focusedBorderColor = HudCyan, unfocusedBorderColor = HudDimCyan, cursorColor = HudCyan
                )
            )

            Spacer(Modifier.height(16.dp))
            Button(
                onClick = { vm.export(context) },
                enabled = !vm.exporting,
                colors = ButtonDefaults.buttonColors(containerColor = HudGold, contentColor = HudBlack),
                shape = RoundedCornerShape(4.dp),
                modifier = Modifier.fillMaxWidth().height(52.dp)
            ) { Text(if (vm.exporting) "EXPORTING..." else "EXPORT VIDEO") }
        }

        Spacer(Modifier.height(12.dp))
        Text(vm.status, color = HudCyan, fontSize = 13.sp)
    }
}
