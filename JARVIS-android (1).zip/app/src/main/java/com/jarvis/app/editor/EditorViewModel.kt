package com.jarvis.app.editor

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.text.Spannable
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class EditorViewModel @Inject constructor() : ViewModel() {
    var videoUri by mutableStateOf<Uri?>(null); private set
    var durationMs by mutableStateOf(0L); private set
    var trimStartMs by mutableStateOf(0f)
    var trimEndMs by mutableStateOf(0f)
    var overlayText by mutableStateOf("")
    var exporting by mutableStateOf(false); private set
    var status by mutableStateOf("Pick a video to start, Sir."); private set

    fun setVideo(context: Context, uri: Uri) {
        viewModelScope.launch {
            val d = withContext(Dispatchers.IO) {
                try {
                    val r = MediaMetadataRetriever()
                    r.setDataSource(context, uri)
                    val v = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                    r.release()
                    v
                } catch (e: Exception) { 0L }
            }
            if (d <= 0L) { status = "I could not read that video, Sir."; return@launch }
            videoUri = uri
            durationMs = d
            trimStartMs = 0f
            trimEndMs = d.toFloat()
            status = "Video loaded. Trim it, add text, then export, Sir."
        }
    }

    fun export(context: Context) {
        val uri = videoUri ?: return
        if (exporting) return
        if (trimEndMs - trimStartMs < 500f) { status = "The trimmed part is too short, Sir."; return }
        exporting = true
        status = "Exporting... please wait, Sir."

        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(trimStartMs.toLong())
            .setEndPositionMs(trimEndMs.toLong())
            .build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()

        val videoEffects = mutableListOf<Effect>()
        if (overlayText.isNotBlank()) {
            val span = SpannableString(overlayText)
            span.setSpan(ForegroundColorSpan(Color.WHITE), 0, span.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            span.setSpan(AbsoluteSizeSpan(72, true), 0, span.length, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
            val settings = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.7f).build()
            videoEffects.add(
                OverlayEffect(ImmutableList.of(TextOverlay.createStaticTextOverlay(span, settings)))
            )
        }
        val edited = EditedMediaItem.Builder(item)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        val out = File(context.cacheDir, "jarvis_edit_${System.currentTimeMillis()}.mp4")
        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    viewModelScope.launch { saveToMovies(context, out) }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    exporting = false
                    status = "Export failed: ${exportException.message}"
                }
            })
            .build()
        transformer.start(edited, out.absolutePath)
    }

    private suspend fun saveToMovies(context: Context, file: File) {
        status = withContext(Dispatchers.IO) {
            try {
                val name = "JARVIS_${System.currentTimeMillis()}.mp4"
                if (Build.VERSION.SDK_INT >= 29) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.DISPLAY_NAME, name)
                        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                        put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/JARVIS")
                    }
                    val target = context.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                        ?: error("Cannot create the file")
                    context.contentResolver.openOutputStream(target)!!.use { os ->
                        file.inputStream().use { it.copyTo(os) }
                    }
                    "Saved to Movies/JARVIS in your gallery, Sir."
                } else {
                    val dir = context.getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                    val dest = File(dir, name)
                    file.copyTo(dest, overwrite = true)
                    "Saved at ${dest.absolutePath}, Sir."
                }
            } catch (e: Exception) {
                "Export finished but saving failed: ${e.message}"
            } finally {
                file.delete()
            }
        }
        exporting = false
    }
}
