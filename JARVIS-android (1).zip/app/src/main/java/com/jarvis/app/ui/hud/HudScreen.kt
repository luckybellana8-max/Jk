package com.jarvis.app.ui.hud

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.content.IntentFilter
import android.os.BatteryManager
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jarvis.app.auth.AuthViewModel
import com.jarvis.app.ui.theme.*
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HudScreen(
    onOpenChat: () -> Unit,
    onOpenEditor: () -> Unit,
    onSignOut: () -> Unit,
    vm: HudViewModel = hiltViewModel(),
    auth: AuthViewModel = hiltViewModel()
) {
    val context = LocalContext.current
    var now by remember { mutableStateOf(Date()) }
    var battery by remember { mutableStateOf("--") }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val dateFmt = remember { SimpleDateFormat("EEEE, dd MMMM yyyy", Locale.getDefault()) }

    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.loadWeather(context)
    }
    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        ) vm.loadWeather(context)
        else locPerm.launch(
            arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)
        )
    }

    LaunchedEffect(Unit) {
        vm.greet()
        while (true) {
            now = Date()
            val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
                battery = "${level * 100 / scale}%" + if (charging) " CHARGING" else ""
            }
            delay(1000)
        }
    }

    Column(
        Modifier.fillMaxSize().background(HudBlack).systemBarsPadding()
            .verticalScroll(rememberScrollState()).padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("J.A.R.V.I.S", color = HudCyan, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 6.sp)
        Spacer(Modifier.height(16.dp))
        ArcReactor(Modifier.size(220.dp))
        Spacer(Modifier.height(16.dp))
        Text(timeFmt.format(now), color = HudCyan, fontSize = 48.sp, fontWeight = FontWeight.Light)
        Text(dateFmt.format(now).uppercase(), color = HudGold, fontSize = 13.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HudPanel("BATTERY", battery, Modifier.weight(1f))
            HudPanel("SYSTEMS", "ONLINE", Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        HudPanel("WEATHER", vm.weather, Modifier.fillMaxWidth())
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = onOpenChat,
            colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = HudBlack),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("TALK TO JARVIS", letterSpacing = 2.sp, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(10.dp))
        Button(
            onClick = onOpenEditor,
            colors = ButtonDefaults.buttonColors(containerColor = HudGold, contentColor = HudBlack),
            shape = RoundedCornerShape(4.dp),
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("VIDEO EDITOR", letterSpacing = 2.sp, fontWeight = FontWeight.Bold) }
        TextButton(onClick = { auth.signOut(); onSignOut() }) {
            Text("SIGN OUT", color = HudDimCyan, fontSize = 12.sp)
        }
    }
}

@Composable
private fun HudPanel(title: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier.border(1.dp, HudDimCyan, RoundedCornerShape(4.dp)).padding(12.dp)
    ) {
        Text(title, color = HudGold, fontSize = 11.sp, letterSpacing = 2.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = HudCyan, fontSize = 15.sp, textAlign = TextAlign.Start)
    }
}

/** 2D animated arc reactor. The 3D, voice-reactive version replaces this in a later update. */
@Composable
fun ArcReactor(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "reactor")
    val pulse by t.animateFloat(
        0.5f, 1f, infiniteRepeatable(tween(1500, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(9000, easing = LinearEasing)), label = "s")
    val spinBack by t.animateFloat(360f, 0f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "sb")
    Canvas(modifier) {
        val c = Offset(size.width / 2, size.height / 2)
        val r = size.minDimension / 2.1f
        drawCircle(HudCyan, radius = r, center = c, style = Stroke(3f))
        drawCircle(HudGold, radius = r * 0.72f, center = c, style = Stroke(2f))
        drawCircle(HudCyan.copy(alpha = pulse), radius = r * 0.22f, center = c)
        drawCircle(HudCyan.copy(alpha = pulse * 0.4f), radius = r * 0.34f, center = c, style = Stroke(6f))
        for (i in 0 until 12) {
            val a = Math.toRadians((spin + i * 30).toDouble())
            drawCircle(HudGold, 4f, Offset(c.x + (r * Math.cos(a)).toFloat(), c.y + (r * Math.sin(a)).toFloat()))
        }
        for (i in 0 until 8) {
            val a = Math.toRadians((spinBack + i * 45).toDouble())
            val rr = r * 0.72f
            drawCircle(HudCyan, 3f, Offset(c.x + (rr * Math.cos(a)).toFloat(), c.y + (rr * Math.sin(a)).toFloat()))
        }
    }
}
