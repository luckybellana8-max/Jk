package com.jarvis.app.ui.hud

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.app.data.WeatherClient
import com.jarvis.app.voice.TtsManager
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HudViewModel @Inject constructor(private val tts: TtsManager) : ViewModel() {
    var weather by mutableStateOf("Loading weather...")
        private set

    fun greet() = tts.greetOnce()

    fun loadWeather(context: Context) {
        viewModelScope.launch { weather = WeatherClient.forCurrentLocation(context) }
    }
}
