package com.jarvis.app.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.jarvis.app.chat.ChatScreen
import com.jarvis.app.editor.EditorScreen
import com.jarvis.app.ui.hud.HudScreen
import com.jarvis.app.ui.splash.SplashScreen

object Routes {
    const val SPLASH = "splash"
    const val HOME = "home"
    const val CHAT = "chat"
    const val EDITOR = "editor"
}

@Composable
fun NavGraph() {
    val nav = rememberNavController()
    NavHost(nav, startDestination = Routes.SPLASH) {
        composable(Routes.SPLASH) {
            SplashScreen(onSignedIn = {
                nav.navigate(Routes.HOME) { popUpTo(Routes.SPLASH) { inclusive = true } }
            })
        }
        composable(Routes.HOME) {
            HudScreen(
                onOpenChat = { nav.navigate(Routes.CHAT) },
                onOpenEditor = { nav.navigate(Routes.EDITOR) },
                onSignOut = { nav.navigate(Routes.SPLASH) { popUpTo(Routes.HOME) { inclusive = true } } }
            )
        }
        composable(Routes.CHAT) { ChatScreen(onBack = { nav.popBackStack() }) }
        composable(Routes.EDITOR) { EditorScreen(onBack = { nav.popBackStack() }) }
    }
}
