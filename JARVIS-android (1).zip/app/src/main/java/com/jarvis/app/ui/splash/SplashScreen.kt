package com.jarvis.app.ui.splash

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import com.jarvis.app.auth.AuthState
import com.jarvis.app.auth.AuthViewModel
import com.jarvis.app.ui.theme.*

@Composable
fun SplashScreen(onSignedIn: () -> Unit, vm: AuthViewModel = hiltViewModel()) {
    val state by vm.state.collectAsState()
    val context = LocalContext.current

    LaunchedEffect(state) { if (state is AuthState.SignedIn) onSignedIn() }

    val t = rememberInfiniteTransition(label = "pulse")
    val pulse by t.animateFloat(
        0.4f, 1f, infiniteRepeatable(tween(1600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "alpha"
    )
    val spin by t.animateFloat(
        0f, 360f, infiniteRepeatable(tween(8000, easing = LinearEasing)), label = "spin"
    )

    Box(Modifier.fillMaxSize().background(HudBlack), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(32.dp)) {
            // Simple 2D arc-reactor placeholder; the 3D reactor arrives in Step 3.
            Canvas(Modifier.size(180.dp).alpha(pulse)) {
                val c = Offset(size.width / 2, size.height / 2)
                drawCircle(HudCyan, radius = size.minDimension / 2.1f, center = c, style = Stroke(3f))
                drawCircle(HudGold, radius = size.minDimension / 3.2f, center = c, style = Stroke(2f))
                drawCircle(HudCyan, radius = size.minDimension / 8f, center = c)
                val r = size.minDimension / 2.1f
                for (i in 0 until 10) {
                    val a = Math.toRadians((spin + i * 36).toDouble())
                    val p = Offset(c.x + (r * Math.cos(a)).toFloat(), c.y + (r * Math.sin(a)).toFloat())
                    drawCircle(HudGold, radius = 4f, center = p)
                }
            }
            Spacer(Modifier.height(32.dp))
            Text("J.A.R.V.I.S", color = HudCyan, fontSize = 38.sp, fontWeight = FontWeight.Bold, letterSpacing = 8.sp)
            Text("Just A Rather Very Intelligent System", color = HudGold, fontSize = 12.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(48.dp))

            when (val s = state) {
                is AuthState.Loading -> CircularProgressIndicator(color = HudCyan)
                else -> {
                    Button(
                        onClick = { vm.signInWithGoogle(context) },
                        colors = ButtonDefaults.buttonColors(containerColor = HudBlack, contentColor = HudCyan),
                        shape = RoundedCornerShape(4.dp),
                        modifier = Modifier.border(1.dp, HudCyan, RoundedCornerShape(4.dp)).fillMaxWidth().height(52.dp)
                    ) { Text("SIGN IN WITH GOOGLE", letterSpacing = 2.sp) }
                    if (s is AuthState.Error) {
                        Spacer(Modifier.height(12.dp))
                        Text(s.message, color = HudGold, fontSize = 12.sp, textAlign = TextAlign.Center)
                    }
                    Spacer(Modifier.height(16.dp))
                    TextButton(onClick = onSignedIn) {
                        Text("CONTINUE WITHOUT SIGN-IN (TEST MODE)", color = HudDimCyan, fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
