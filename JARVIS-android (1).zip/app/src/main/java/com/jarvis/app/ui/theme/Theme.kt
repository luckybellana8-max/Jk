package com.jarvis.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val HudBlack = Color(0xFF000000)
val HudCyan = Color(0xFF00E5FF)
val HudGold = Color(0xFFFFC107)
val HudPanel = Color(0xFF0A0F14)
val HudDimCyan = Color(0x6600E5FF)

private val JarvisColors = darkColorScheme(
    primary = HudCyan,
    secondary = HudGold,
    background = HudBlack,
    surface = HudPanel,
    onPrimary = HudBlack,
    onBackground = HudCyan,
    onSurface = HudCyan
)

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = JarvisColors, content = content)
}
