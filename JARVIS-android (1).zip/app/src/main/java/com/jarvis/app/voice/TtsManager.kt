package com.jarvis.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import com.jarvis.app.core.Persona
import dagger.hilt.android.qualifiers.ApplicationContext
import java.util.Locale
import javax.inject.Inject
import javax.inject.Singleton

/** Speaks with Android's built-in voice, pitched down for a deeper JARVIS tone. */
@Singleton
class TtsManager @Inject constructor(@ApplicationContext context: Context) : TextToSpeech.OnInitListener {
    private val tts = TextToSpeech(context, this)
    private var ready = false
    private var queued: String? = null
    private var greeted = false

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            tts.language = Locale.UK
            tts.setPitch(0.55f)
            tts.setSpeechRate(0.92f)
            ready = true
            queued?.let { speak(it); queued = null }
        }
    }

    fun speak(text: String) {
        if (!ready) { queued = text; return }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis")
    }

    fun greetOnce() {
        if (greeted) return
        greeted = true
        speak(Persona.GREETING)
    }
}
